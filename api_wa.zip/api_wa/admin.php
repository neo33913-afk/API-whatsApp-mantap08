<?php

session_start();

require_once "config/database.php";

/*
|--------------------------------------------------------------------------
| CEK LOGIN
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

/*
|--------------------------------------------------------------------------
| CEK ROLE ADMIN
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION["user_role"]) || $_SESSION["user_role"] !== "admin") {
    die("Akses ditolak. Halaman ini hanya untuk admin.");
}

/*
|--------------------------------------------------------------------------
| DATA ADMIN LOGIN
|--------------------------------------------------------------------------
*/

$adminNama = $_SESSION["user_nama"] ?? "Admin";

/*
|--------------------------------------------------------------------------
| AMBIL SEMUA USER
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT
        id,
        nama,
        email,
        no_hp,
        alamat,
        role,
        created_at
    FROM users
    ORDER BY created_at DESC
");

$stmt->execute();

$result = $stmt->get_result();

/*
|--------------------------------------------------------------------------
| TOTAL SEMUA USER
|--------------------------------------------------------------------------
*/

$stmtTotal = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM users
");

$stmtTotal->execute();

$totalUser = $stmtTotal
    ->get_result()
    ->fetch_assoc()["total"];

$stmtTotal->close();

/*
|--------------------------------------------------------------------------
| TOTAL ADMIN
|--------------------------------------------------------------------------
*/

$stmtAdmin = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM users
    WHERE role = 'admin'
");

$stmtAdmin->execute();

$totalAdmin = $stmtAdmin
    ->get_result()
    ->fetch_assoc()["total"];

$stmtAdmin->close();

/*
|--------------------------------------------------------------------------
| TOTAL USER BIASA
|--------------------------------------------------------------------------
*/

$stmtUser = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM users
    WHERE role = 'user'
");

$stmtUser->execute();

$totalUserBiasa = $stmtUser
    ->get_result()
    ->fetch_assoc()["total"];

$stmtUser->close();

/*
|--------------------------------------------------------------------------
| NOTIFIKASI USER BARU
|--------------------------------------------------------------------------
| User yang mendaftar dalam 24 jam terakhir
|--------------------------------------------------------------------------
*/

$stmtNotif = $conn->prepare("
    SELECT
        id,
        nama,
        email,
        created_at
    FROM users
    WHERE role = 'user'
    AND created_at >= NOW() - INTERVAL 1 DAY
    ORDER BY created_at DESC
");

$stmtNotif->execute();

$notifResult = $stmtNotif->get_result();

$jumlahNotif = $notifResult->num_rows;

/*
|--------------------------------------------------------------------------
| MODE EDIT
|--------------------------------------------------------------------------
*/

$editUser = null;

if (isset($_GET["edit"])) {

    $editId = intval($_GET["edit"]);

    if ($editId > 0) {

        $stmtEdit = $conn->prepare("
            SELECT
                id,
                nama,
                email,
                no_hp,
                alamat,
                role
            FROM users
            WHERE id = ?
        ");

        $stmtEdit->bind_param(
            "i",
            $editId
        );

        $stmtEdit->execute();

        $editUser = $stmtEdit
            ->get_result()
            ->fetch_assoc();

        $stmtEdit->close();
    }
}

/*
|--------------------------------------------------------------------------
| SUCCESS / ERROR
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| TAB AKTIF (data / tambah / edit)
|--------------------------------------------------------------------------
*/

$activeTab = "data";

if ($editUser) {
    $activeTab = "edit";
} elseif (($_GET["tab"] ?? "") === "tambah") {
    $activeTab = "tambah";
}

$success = $_GET["success"] ?? "";
$error   = $_GET["error"] ?? "";

?>

<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Admin Dashboard</title>


    <style>

        /*
        |--------------------------------------------------------------------------
        | GLOBAL
        |--------------------------------------------------------------------------
        */

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;

            font-family:
                Arial,
                Helvetica,
                sans-serif;

            background: #f4f7f6;

            color: #222;
        }


        /*
        |--------------------------------------------------------------------------
        | NAVBAR
        |--------------------------------------------------------------------------
        */

        .navbar {

            background: #25D366;

            color: white;

            padding: 15px 30px;

            display: flex;

            justify-content: space-between;

            align-items: center;

            box-shadow:
                0 2px 8px rgba(0,0,0,0.15);
        }

        .navbar h1 {

            margin: 0;

            font-size: 22px;
        }

        .navbar-right {

            display: flex;

            align-items: center;

            gap: 15px;
        }

        .admin-name {

            font-weight: bold;
        }

        .logout {

            background: white;

            color: #198754;

            padding: 8px 14px;

            border-radius: 6px;

            text-decoration: none;

            font-weight: bold;
        }

        .logout:hover {

            background: #f1f1f1;
        }


        /*
        |--------------------------------------------------------------------------
        | CONTAINER
        |--------------------------------------------------------------------------
        */

        .container {

            width: 95%;

            max-width: 1400px;

            margin: 30px auto;
        }


        /*
        |--------------------------------------------------------------------------
        | PAGE HEADER
        |--------------------------------------------------------------------------
        */

        .page-header {

            margin-bottom: 25px;
        }

        .page-header h2 {

            margin:
                0 0 5px 0;
        }

        .page-header p {

            margin: 0;

            color: #777;
        }


        /*
        |--------------------------------------------------------------------------
        | ALERT
        |--------------------------------------------------------------------------
        */

        .alert {

            padding: 14px 18px;

            border-radius: 8px;

            margin-bottom: 20px;

            font-weight: bold;
        }

        .alert-success {

            background: #d1e7dd;

            color: #0f5132;
        }

        .alert-error {

            background: #f8d7da;

            color: #842029;
        }


        /*
        |--------------------------------------------------------------------------
        | STATISTICS
        |--------------------------------------------------------------------------
        */

        .stats {

            display: grid;

            grid-template-columns:
                repeat(3, 1fr);

            gap: 20px;

            margin-bottom: 25px;
        }

        .stat-card {

            background: white;

            padding: 22px;

            border-radius: 12px;

            box-shadow:
                0 4px 12px
                rgba(0,0,0,0.07);
        }

        .stat-card h3 {

            margin:
                0 0 10px 0;

            color: #666;

            font-size: 15px;
        }

        .stat-number {

            font-size: 30px;

            font-weight: bold;

            color: #25D366;
        }


        /*
        |--------------------------------------------------------------------------
        | CARD
        |--------------------------------------------------------------------------
        */

        .card {

            background: white;

            padding: 22px;

            border-radius: 12px;

            margin-bottom: 25px;

            box-shadow:
                0 4px 12px
                rgba(0,0,0,0.07);
        }

        .card h2 {

            margin-top: 0;

            margin-bottom: 18px;
        }


        /*
        |--------------------------------------------------------------------------
        | NOTIFICATION
        |--------------------------------------------------------------------------
        */

        .notification {

            background: white;

            padding: 22px;

            border-radius: 12px;

            margin-bottom: 25px;

            box-shadow:
                0 4px 12px
                rgba(0,0,0,0.07);
        }

        .notification h2 {

            margin-top: 0;
        }

        .notif-header {

            background: #e8f8ee;

            color: #198754;

            padding: 13px;

            border-radius: 8px;

            margin-bottom: 12px;

            font-weight: bold;
        }

        .notif-item {

            border-left:
                4px solid #25D366;

            background: #f8f9fa;

            padding: 13px 15px;

            margin-bottom: 10px;

            border-radius: 7px;
        }

        .notif-item strong {

            display: block;

            margin-bottom: 5px;
        }

        .notif-item .email {

            color: #555;

            font-size: 14px;
        }

        .notif-item small {

            display: block;

            margin-top: 6px;

            color: #888;
        }

        .notif-empty {

            background: #f1f1f1;

            padding: 13px;

            border-radius: 8px;

            color: #666;
        }


        /*
        |--------------------------------------------------------------------------
        | FORM GRID
        |--------------------------------------------------------------------------
        */

        .form-grid {

            display: grid;

            grid-template-columns:
                repeat(2, 1fr);

            gap: 16px;

            margin-bottom: 20px;
        }

        .form-group label {

            display: block;

            margin-bottom: 7px;

            font-weight: bold;
        }

        .form-group input,
        .form-group select {

            width: 100%;

            padding: 11px;

            border:
                1px solid #ddd;

            border-radius: 7px;

            font-size: 14px;

            outline: none;
        }

        .form-group input:focus,
        .form-group select:focus {

            border-color: #25D366;
        }

        .password-info {

            font-size: 12px;

            color: #777;

            margin-top: 5px;
        }


        /*
        |--------------------------------------------------------------------------
        | BUTTON
        |--------------------------------------------------------------------------
        */

        .btn {

            display: inline-block;

            padding: 9px 14px;

            border: none;

            border-radius: 7px;

            text-decoration: none;

            cursor: pointer;

            font-size: 14px;

            font-weight: bold;
        }

        .btn-primary {

            background: #25D366;

            color: white;
        }

        .btn-primary:hover {

            background: #1ebe5d;
        }

        .btn-edit {

            background: #ffc107;

            color: #000;
        }

        .btn-edit:hover {

            background: #e0a800;
        }

        .btn-delete {

            background: #dc3545;

            color: white;
        }

        .btn-delete:hover {

            background: #bb2d3b;
        }

        .btn-cancel {

            background: #6c757d;

            color: white;
        }

        .btn-cancel:hover {

            background: #5c636a;
        }


        /*
        |--------------------------------------------------------------------------
        | TABLE
        |--------------------------------------------------------------------------
        */

        .table-wrapper {

            overflow-x: auto;
        }

        table {

            width: 100%;

            border-collapse: collapse;

            min-width: 1000px;
        }

        table th {

            background: #25D366;

            color: white;

            padding: 12px;

            text-align: left;
        }

        table td {

            padding: 12px;

            border-bottom:
                1px solid #eee;

            vertical-align: middle;
        }

        table tr:hover {

            background: #f8f9fa;
        }


        /*
        |--------------------------------------------------------------------------
        | BADGE
        |--------------------------------------------------------------------------
        */

        .badge {

            display: inline-block;

            padding: 5px 10px;

            border-radius: 20px;

            font-size: 12px;

            font-weight: bold;
        }

        .badge-admin {

            background: #d1e7dd;

            color: #0f5132;
        }

        .badge-user {

            background: #e2e3e5;

            color: #41464b;
        }


        /*
        |--------------------------------------------------------------------------
        | ACTION
        |--------------------------------------------------------------------------
        */

        .action-group {

            display: flex;

            gap: 6px;

            align-items: center;
        }

        .action-group form {

            margin: 0;
        }


        /*
        |--------------------------------------------------------------------------
        | RESPONSIVE
        |--------------------------------------------------------------------------
        */

        @media (max-width: 800px) {

            .stats {

                grid-template-columns: 1fr;
            }

            .form-grid {

                grid-template-columns: 1fr;
            }

            .navbar {

                padding: 15px;

                flex-direction: column;

                gap: 12px;

                align-items: flex-start;
            }

            .navbar-right {

                width: 100%;

                justify-content: space-between;
            }

            .container {

                width: 92%;
            }
        }

        /*
        |--------------------------------------------------------------------------
        | TABS (PAGINATION MENU)
        |--------------------------------------------------------------------------
        */

        .tabs {
            display: flex;
            gap: 8px;
            margin-bottom: 20px;
            padding: 8px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.07);
            overflow-x: auto;
        }

        .tab-btn {
            flex: 1;
            min-width: 140px;
            padding: 12px 18px;
            border: none;
            border-radius: 8px;
            background: transparent;
            color: #555;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
            white-space: nowrap;
            transition: background 0.15s, color 0.15s;
        }

        .tab-btn:hover {
            background: #e8f8ee;
            color: #198754;
        }

        .tab-btn.active {
            background: #25D366;
            color: white;
        }

        .tab-panel {
            display: none;
        }

        .tab-panel.active {
            display: block;
        }

        .form-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

    </style>

</head>


<body>


<!--
|--------------------------------------------------------------------------
| NAVBAR
|--------------------------------------------------------------------------
-->

<div class="navbar">

    <h1>
        📊 Admin Dashboard
    </h1>


    <div class="navbar-right">

        <span class="admin-name">

            👤
            <?= htmlspecialchars($adminNama) ?>

        </span>


        <a
            href="logout.php"
            class="logout"
        >
            Logout
        </a>

    </div>

</div>


<div class="container">


    <!--
    |--------------------------------------------------------------------------
    | PAGE HEADER
    |--------------------------------------------------------------------------
    -->

    <div class="page-header">

        <h2>
            Selamat Datang, Admin 👋
        </h2>

        <p>
            Kelola seluruh data pengguna melalui dashboard admin.
        </p>

    </div>


    <!--
    |--------------------------------------------------------------------------
    | SUCCESS MESSAGE
    |--------------------------------------------------------------------------
    -->

    <?php if ($success === "created_wa"): ?>

        <div class="alert alert-success">

            ✅ User berhasil ditambahkan
            dan notifikasi WhatsApp berhasil dikirim.

        </div>


    <?php elseif ($success === "created_wa_failed"): ?>

        <div class="alert alert-error">

            ⚠️ User berhasil ditambahkan,
            tetapi notifikasi WhatsApp gagal dikirim.

        </div>


    <?php elseif ($success === "updated_wa"): ?>

        <div class="alert alert-success">

            ✅ Data user berhasil diperbarui
            dan notifikasi WhatsApp berhasil dikirim.

        </div>


    <?php elseif ($success === "updated_wa_failed"): ?>

        <div class="alert alert-error">

            ⚠️ Data user berhasil diperbarui,
            tetapi notifikasi WhatsApp gagal dikirim.

        </div>


    <?php elseif ($success === "updated"): ?>

        <div class="alert alert-success">

            ✅ Data user berhasil diperbarui.

        </div>


    <?php elseif ($success === "deleted_wa"): ?>

        <div class="alert alert-success">

            ✅ User berhasil dihapus
            dan notifikasi WhatsApp berhasil dikirim.

        </div>


    <?php elseif ($success === "deleted_wa_failed"): ?>

        <div class="alert alert-error">

            ⚠️ User berhasil dihapus,
            tetapi notifikasi WhatsApp gagal dikirim.

        </div>


    <?php elseif ($success === "deleted"): ?>

        <div class="alert alert-success">

            ✅ User berhasil dihapus.

        </div>

    <?php endif; ?>


    <!--
    |--------------------------------------------------------------------------
    | ERROR MESSAGE
    |--------------------------------------------------------------------------
    -->

    <?php if ($error === "empty"): ?>

        <div class="alert alert-error">

            ❌ Semua data wajib diisi.

        </div>


    <?php elseif ($error === "email"): ?>

        <div class="alert alert-error">

            ❌ Format email tidak valid.

        </div>


    <?php elseif ($error === "email_exists"): ?>

        <div class="alert alert-error">

            ❌ Email tersebut sudah digunakan.

        </div>


    <?php elseif ($error === "self_delete"): ?>

        <div class="alert alert-error">

            ❌ Admin tidak dapat menghapus akun sendiri.

        </div>


    <?php elseif ($error === "invalid"): ?>

        <div class="alert alert-error">

            ❌ Data tidak valid.

        </div>


    <?php elseif ($error === "update_failed"): ?>

        <div class="alert alert-error">

            ❌ Data user gagal diperbarui.

        </div>


    <?php elseif ($error === "create_failed"): ?>

        <div class="alert alert-error">

            ❌ User gagal ditambahkan.

        </div>


    <?php elseif ($error === "delete_failed"): ?>

        <div class="alert alert-error">

            ❌ User gagal dihapus.

        </div>

    <?php endif; ?>


    <!--
    |--------------------------------------------------------------------------
    | STATISTICS
    |--------------------------------------------------------------------------
    -->

    <div class="stats">


        <div class="stat-card">

            <h3>
                👥 Total User
            </h3>

            <div class="stat-number">

                <?= $totalUser ?>

            </div>

        </div>


        <div class="stat-card">

            <h3>
                🛡️ Total Admin
            </h3>

            <div class="stat-number">

                <?= $totalAdmin ?>

            </div>

        </div>


        <div class="stat-card">

            <h3>
                👤 User Biasa
            </h3>

            <div class="stat-number">

                <?= $totalUserBiasa ?>

            </div>

        </div>


    </div>


    <!--
    |--------------------------------------------------------------------------
    | NOTIFICATION
    |--------------------------------------------------------------------------
    -->

    <div class="notification">

        <h2>
            🔔 Notifikasi User Baru
        </h2>


        <?php if ($jumlahNotif > 0): ?>

            <div class="notif-header">

                🟢 Ada
                <?= $jumlahNotif ?>
                user baru dalam 24 jam terakhir.

            </div>


            <?php while ($notif = $notifResult->fetch_assoc()): ?>

                <div class="notif-item">

                    <strong>

                        👤
                        <?= htmlspecialchars($notif["nama"]) ?>

                    </strong>


                    <div class="email">

                        📧
                        <?= htmlspecialchars($notif["email"]) ?>

                    </div>


                    <small>

                        🕐
                        <?= htmlspecialchars($notif["created_at"]) ?>

                    </small>

                </div>

            <?php endwhile; ?>


        <?php else: ?>

            <div class="notif-empty">

                ✅ Tidak ada user baru
                dalam 24 jam terakhir.

            </div>

        <?php endif; ?>

    </div>


    <!--
    |--------------------------------------------------------------------------
    | EDIT USER
    |--------------------------------------------------------------------------
    -->

    <div class="tabs">

        <button type="button" class="tab-btn <?= $activeTab === "data" ? "active" : "" ?>" data-tab="data">
            👥 Data User
        </button>

        <button type="button" class="tab-btn <?= $activeTab === "tambah" ? "active" : "" ?>" data-tab="tambah">
            ➕ Tambah User
        </button>

        <?php if ($editUser): ?>
            <button type="button" class="tab-btn <?= $activeTab === "edit" ? "active" : "" ?>" data-tab="edit">
                ✏️ Edit User
            </button>
        <?php endif; ?>

    </div>


    <?php if ($editUser): ?>

        <div class="tab-panel <?= $activeTab === "edit" ? "active" : "" ?>" id="panel-edit">

        <div class="card">

            <h2>
                ✏️ Edit User
            </h2>


            <form
                action="api/admin_edit.php"
                method="POST"
            >


                <input
                    type="hidden"
                    name="id"
                    value="<?= $editUser["id"] ?>"
                >


                <div class="form-grid">


                    <!-- NAMA -->

                    <div class="form-group">

                        <label>
                            Nama
                        </label>

                        <input
                            type="text"
                            name="nama"
                            value="<?= htmlspecialchars($editUser["nama"]) ?>"
                            required
                        >

                    </div>


                    <!-- EMAIL -->

                    <div class="form-group">

                        <label>
                            Email
                        </label>

                        <input
                            type="email"
                            name="email"
                            value="<?= htmlspecialchars($editUser["email"]) ?>"
                            required
                        >

                    </div>


                    <!-- NOMOR -->

                    <div class="form-group">

                        <label>
                            No. WhatsApp
                        </label>

                        <input
                            type="text"
                            name="no_hp"
                            value="<?= htmlspecialchars($editUser["no_hp"]) ?>"
                            required
                        >

                    </div>


                    <!-- ROLE -->

                    <div class="form-group">

                        <label>
                            Role
                        </label>


                        <select name="role">


                            <option
                                value="user"
                                <?= $editUser["role"] === "user"
                                    ? "selected"
                                    : "" ?>
                            >

                                User

                            </option>


                            <option
                                value="admin"
                                <?= $editUser["role"] === "admin"
                                    ? "selected"
                                    : "" ?>
                            >

                                Admin

                            </option>


                        </select>

                    </div>


                    <!-- PASSWORD -->

                    <div class="form-group">

                        <label>
                            Password Baru
                        </label>


                        <input
                            type="password"
                            name="password"
                            placeholder="Kosongkan jika tidak diubah"
                        >


                        <div class="password-info">

                            Kosongkan jika password
                            tidak ingin diubah.

                        </div>

                    </div>


                    <!-- ALAMAT -->

                    <div class="form-group">

                        <label>
                            Alamat
                        </label>


                        <input
                            type="text"
                            name="alamat"
                            value="<?= htmlspecialchars($editUser["alamat"]) ?>"
                            required
                        >

                    </div>


                </div>


                <button
                    type="submit"
                    class="btn btn-primary"
                >

                    💾 Simpan Perubahan

                </button>


                <a
                    href="admin.php"
                    class="btn btn-cancel"
                >

                    Batal

                </a>


            </form>

        </div>

        </div><!-- /panel-edit -->

    <?php endif; ?>


    <!--
    |--------------------------------------------------------------------------
    | TAMBAH USER
    |--------------------------------------------------------------------------
    -->

    <div class="tab-panel <?= $activeTab === "tambah" ? "active" : "" ?>" id="panel-tambah">

    <div class="card">

        <h2>
            ➕ Tambah User
        </h2>


        <form
            action="api/admin_create.php"
            method="POST"
        >


            <div class="form-grid">


                <!-- NAMA -->

                <div class="form-group">

                    <label>
                        Nama
                    </label>

                    <input
                        type="text"
                        name="nama"
                        placeholder="Masukkan nama"
                        required
                    >

                </div>


                <!-- EMAIL -->

                <div class="form-group">

                    <label>
                        Email
                    </label>

                    <input
                        type="email"
                        name="email"
                        placeholder="Masukkan email"
                        required
                    >

                </div>


                <!-- NOMOR -->

                <div class="form-group">

                    <label>
                        No. WhatsApp
                    </label>

                    <input
                        type="text"
                        name="no_hp"
                        placeholder="Contoh: 6285784691260"
                        required
                    >

                </div>


                <!-- ROLE -->

                <div class="form-group">

                    <label>
                        Role
                    </label>


                    <select name="role">

                        <option value="user">
                            User
                        </option>

                        <option value="admin">
                            Admin
                        </option>

                    </select>

                </div>


                <!-- PASSWORD -->

                <div class="form-group">

                    <label>
                        Password
                    </label>

                    <input
                        type="password"
                        name="password"
                        placeholder="Masukkan password"
                        required
                    >

                </div>


                <!-- ALAMAT -->

                <div class="form-group">

                    <label>
                        Alamat
                    </label>

                    <input
                        type="text"
                        name="alamat"
                        placeholder="Masukkan alamat"
                        required
                    >

                </div>


            </div>


            <button
                type="submit"
                class="btn btn-primary"
            >

                ➕ Tambah User

            </button>


        </form>

    </div>


    </div><!-- /panel-tambah -->


    <!--
    |--------------------------------------------------------------------------
    | DATA USER
    |--------------------------------------------------------------------------
    -->

    <div class="tab-panel <?= $activeTab === "data" ? "active" : "" ?>" id="panel-data">

    <div class="card">

        <h2>
            👥 Data Semua User
        </h2>


        <div class="table-wrapper">


            <table>


                <thead>

                    <tr>

                        <th>
                            ID
                        </th>

                        <th>
                            Nama
                        </th>

                        <th>
                            Email
                        </th>

                        <th>
                            No. WhatsApp
                        </th>

                        <th>
                            Alamat
                        </th>

                        <th>
                            Role
                        </th>

                        <th>
                            Dibuat
                        </th>

                        <th>
                            Aksi
                        </th>

                    </tr>

                </thead>


                <tbody>


                    <?php if ($result->num_rows > 0): ?>


                        <?php while ($user = $result->fetch_assoc()): ?>


                            <tr>


                                <!-- ID -->

                                <td>

                                    <?= $user["id"] ?>

                                </td>


                                <!-- NAMA -->

                                <td>

                                    <?= htmlspecialchars($user["nama"]) ?>

                                </td>


                                <!-- EMAIL -->

                                <td>

                                    <?= htmlspecialchars($user["email"]) ?>

                                </td>


                                <!-- NOMOR -->

                                <td>

                                    <?= htmlspecialchars($user["no_hp"]) ?>

                                </td>


                                <!-- ALAMAT -->

                                <td>

                                    <?= htmlspecialchars($user["alamat"]) ?>

                                </td>


                                <!-- ROLE -->

                                <td>


                                    <?php if ($user["role"] === "admin"): ?>


                                        <span class="badge badge-admin">

                                            ADMIN

                                        </span>


                                    <?php else: ?>


                                        <span class="badge badge-user">

                                            USER

                                        </span>


                                    <?php endif; ?>


                                </td>


                                <!-- CREATED -->

                                <td>

                                    <?= htmlspecialchars($user["created_at"]) ?>

                                </td>


                                <!-- ACTION -->

                                <td>


                                    <div class="action-group">


                                        <!-- EDIT -->

                                        <a
                                            href="admin.php?edit=<?= $user["id"] ?>"
                                            class="btn btn-edit"
                                        >

                                            ✏️ Edit

                                        </a>


                                        <!-- DELETE -->

                                        <?php if ($user["id"] != $_SESSION["user_id"]): ?>


                                            <form
                                                action="api/admin_delete.php"
                                                method="POST"
                                                onsubmit="return confirm('Yakin ingin menghapus akun <?= htmlspecialchars($user["nama"], ENT_QUOTES) ?>?');"
                                            >


                                                <input
                                                    type="hidden"
                                                    name="id"
                                                    value="<?= $user["id"] ?>"
                                                >


                                                <button
                                                    type="submit"
                                                    class="btn btn-delete"
                                                >

                                                    🗑️ Hapus

                                                </button>


                                            </form>


                                        <?php else: ?>


                                            <span
                                                class="badge badge-admin"
                                            >

                                                Akun Anda

                                            </span>


                                        <?php endif; ?>


                                    </div>


                                </td>


                            </tr>


                        <?php endwhile; ?>


                    <?php else: ?>


                        <tr>


                            <td
                                colspan="8"
                                style="text-align:center;"
                            >

                                Belum ada data user.

                            </td>


                        </tr>


                    <?php endif; ?>


                </tbody>


            </table>


        </div>

    </div><!-- /panel-data -->


</div>


<script>
    (function () {
        var buttons = document.querySelectorAll(".tab-btn");
        var panels  = document.querySelectorAll(".tab-panel");

        function showTab(name) {
            buttons.forEach(function (b) {
                b.classList.toggle("active", b.dataset.tab === name);
            });
            panels.forEach(function (p) {
                p.classList.toggle("active", p.id === "panel-" + name);
            });
        }

        buttons.forEach(function (b) {
            b.addEventListener("click", function () {
                showTab(b.dataset.tab);
            });
        });
    })();
</script>


</body>

</html>


<?php

/*
|--------------------------------------------------------------------------
| TUTUP DATABASE
|--------------------------------------------------------------------------
*/

$stmt->close();

$stmtNotif->close();

$conn->close();

?>