<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

require_once "config/database.php";

$user_id = (int) $_SESSION["user_id"];

$stmt = $conn->prepare("SELECT nama, email, no_hp, alamat FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();
$conn->close();

if (!$user) {
    // Data tidak ditemukan, mungkin akun sudah dihapus
    session_destroy();
    header("Location: login.php");
    exit;
}

function h($v) {
    return htmlspecialchars((string) $v, ENT_QUOTES, "UTF-8");
}

$hapusErrors = [
    "empty"   => "Password wajib diisi untuk konfirmasi hapus akun.",
    "invalid" => "Password salah, akun tidak dihapus.",
];
$hapusErrorMsg = $hapusErrors[$_GET["hapus_error"] ?? ""] ?? "";
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Edit Profil • API WhatsApp</title>
  <style>
    :root {
      --wa: #128c7e;
      --wa-dark: #075e54;
      --wa-soft: #d9fdd3;
      --ink: #12221f;
      --muted: #5b6f6a;
      --line: #d7e4e0;
      --bg: #eef6f3;
      --card: #ffffff;
      --danger: #c0392b;
    }
    * { box-sizing: border-box; }
    html, body { margin: 0; padding: 0; }
    body {
      min-height: 100vh;
      font-family: "Segoe UI", system-ui, sans-serif;
      color: var(--ink);
      background:
        radial-gradient(1200px 500px at -10% -20%, #c8f0d8 0%, transparent 50%),
        radial-gradient(900px 400px at 110% 0%, #bfe8e0 0%, transparent 46%),
        var(--bg);
    }
    .wrap {
      max-width: 640px;
      margin: 0 auto;
      padding: 28px 16px 48px;
    }
    .badge {
      display: inline-block;
      background: var(--wa-soft);
      color: var(--wa-dark);
      font-size: 12px;
      font-weight: 700;
      letter-spacing: .04em;
      padding: 6px 10px;
      border-radius: 999px;
    }
    .card {
      background: var(--card);
      border: 1px solid #e3eeea;
      border-radius: 20px;
      padding: 22px 20px 18px;
      box-shadow: 0 18px 40px rgba(16, 64, 52, .08);
      margin-top: 14px;
    }
    .card h2 { margin: 0 0 4px; font-size: 22px; }
    .sub { margin: 0 0 18px; color: var(--muted); font-size: 14px; }
    form { display: grid; gap: 12px; }
    label { font-size: 13px; font-weight: 700; }
    .field { display: grid; gap: 6px; }
    .control { position: relative; }
    input, textarea {
      width: 100%;
      border: 1.5px solid var(--line);
      border-radius: 12px;
      padding: 12px 12px;
      font: inherit;
      color: var(--ink);
      background: #fbfefe;
      outline: none;
    }
    textarea { min-height: 84px; resize: vertical; }
    input:focus, textarea:focus {
      border-color: var(--wa);
      box-shadow: 0 0 0 4px rgba(18, 140, 126, .15);
    }
    .eye {
      position: absolute;
      right: 8px; top: 50%;
      transform: translateY(-50%);
      border: 0; background: transparent;
      color: var(--muted);
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;
      padding: 6px;
    }
    .hint { color: var(--muted); font-size: 12px; }
    .row { display: grid; gap: 12px; }
    @media (min-width: 640px) {
      .row { grid-template-columns: 1fr 1fr; }
    }
    hr {
      border: none;
      border-top: 1px dashed var(--line);
      margin: 6px 0;
    }
    button[type="submit"] {
      margin-top: 6px;
      width: 100%;
      border: 0;
      border-radius: 12px;
      padding: 13px 16px;
      background: linear-gradient(180deg, #1aaa7b, var(--wa-dark));
      color: white;
      font: inherit;
      font-weight: 800;
      cursor: pointer;
    }
    button[type="submit"]:hover { filter: brightness(1.05); }
    .legal {
      margin-top: 10px;
      font-size: 12px;
      color: var(--muted);
      text-align: center;
    }
    .topnav { display:flex; justify-content:space-between; align-items:center; gap:12px; padding:14px 16px 0; }
    .topnav .who { color: var(--muted); font-size: 13px; }
    .topnav .links { display:flex; gap:12px; }
    .topnav a { color:#075e54; font-weight:800; text-decoration:none; }
    .alert {
      background: #fdecea;
      border: 1px solid #f5c6c0;
      color: var(--danger);
      font-size: 13px;
      padding: 10px 12px;
      border-radius: 10px;
      margin-bottom: 14px;
    }
    .danger-card {
      background: #fff8f7;
      border: 1px solid #f3d3ce;
      border-radius: 20px;
      padding: 22px 20px 18px;
      margin-top: 14px;
    }
    .danger-card h2 { margin: 0 0 4px; font-size: 18px; color: var(--danger); }
    .danger-card .sub { color: var(--muted); }
    button.btn-danger {
      margin-top: 6px;
      width: 100%;
      border: 0;
      border-radius: 12px;
      padding: 13px 16px;
      background: var(--danger);
      color: white;
      font: inherit;
      font-weight: 800;
      cursor: pointer;
    }
    button.btn-danger:hover { filter: brightness(1.08); }
  </style>
</head>
<body>
  <div class="topnav">
    <div class="who">Masuk sebagai <strong><?= h($user["nama"]) ?></strong></div>
    <div class="links">
      <a href="laporan.php">Laporan</a>
      <a href="logout.php">Keluar</a>
    </div>
  </div>
  <div class="wrap">
    <span class="badge">API WHATSAPP</span>
    <div class="card">
      <h2>Edit profil</h2>
      <p class="sub">Perubahan data akan dikirim sebagai notifikasi ke WhatsApp Anda.</p>

      <?php if ($hapusErrorMsg): ?>
        <div class="alert"><?= h($hapusErrorMsg) ?></div>
      <?php endif; ?>

      <form id="editForm" action="api/edit.php" method="POST" novalidate>
        <div class="row">
          <div class="field">
            <label for="nama">Nama</label>
            <input id="nama" name="nama" type="text" autocomplete="name" value="<?= h($user["nama"]) ?>" required />
          </div>
          <div class="field">
            <label for="email">Email</label>
            <input id="email" name="email" type="email" autocomplete="email" value="<?= h($user["email"]) ?>" required />
          </div>
        </div>

        <div class="field">
          <label for="no_hp">Nomor WhatsApp</label>
          <input id="no_hp" name="no_hp" type="tel" inputmode="numeric" autocomplete="tel" value="<?= h($user["no_hp"]) ?>" required />
          <div class="hint">Kalau nomor diganti, notifikasi dikirim ke nomor yang BARU.</div>
        </div>

        <div class="field">
          <label for="alamat">Alamat</label>
          <textarea id="alamat" name="alamat" required><?= h($user["alamat"]) ?></textarea>
        </div>

        <hr />

        <div class="field">
          <label for="password_baru">Password baru (opsional)</label>
          <div class="control">
            <input id="password_baru" name="password_baru" type="password" autocomplete="new-password" minlength="8" placeholder="Kosongkan jika tidak ingin ganti password" />
            <button class="eye" type="button" id="togglePass">Lihat</button>
          </div>
          <div class="hint">Isi hanya jika ingin mengganti password. Minimal 8 karakter.</div>
        </div>

        <button type="submit" id="submitBtn">Simpan perubahan</button>
        <p class="legal">Data dikirim ke <code>api/edit.php</code>.</p>
      </form>
    </div>

    <div class="danger-card">
      <h2>Hapus akun</h2>
      <p class="sub">Tindakan ini permanen. Notifikasi WA akan dikirim ke nomor Anda sebagai konfirmasi.</p>

      <form id="deleteForm" action="api/delete_self.php" method="POST"
            onsubmit="return confirm('Yakin mau hapus akun? Tindakan ini tidak bisa dibatalkan.');">
        <div class="field">
          <label for="password_konfirmasi">Konfirmasi password</label>
          <div class="control">
            <input id="password_konfirmasi" name="password_konfirmasi" type="password" autocomplete="current-password" placeholder="Masukkan password Anda" required />
            <button class="eye" type="button" id="toggleDelPass">Lihat</button>
          </div>
        </div>
        <button type="submit" class="btn-danger">Hapus akun saya</button>
      </form>
    </div>
  </div>

  <script>
    const form = document.getElementById("editForm");
    const toggle = document.getElementById("togglePass");
    const pass = document.getElementById("password_baru");

    toggle.addEventListener("click", () => {
      const show = pass.type === "password";
      pass.type = show ? "text" : "password";
      toggle.textContent = show ? "Sembunyi" : "Lihat";
    });

    form.addEventListener("submit", (e) => {
      const pwd = pass.value;
      if (pwd.length > 0 && pwd.length < 8) {
        e.preventDefault();
        alert("Password baru minimal 8 karakter.");
        return;
      }
      document.getElementById("submitBtn").disabled = true;
    });

    const toggleDelPass = document.getElementById("toggleDelPass");
    const delPass = document.getElementById("password_konfirmasi");
    toggleDelPass.addEventListener("click", () => {
      const show = delPass.type === "password";
      delPass.type = show ? "text" : "password";
      toggleDelPass.textContent = show ? "Sembunyi" : "Lihat";
    });
  </script>
</body>
</html>
