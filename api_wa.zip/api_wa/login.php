<?php
session_start();
if (isset($_SESSION["user_id"])) {
    header("Location: edit.php");
    exit;
}

$errors = [
    "empty"   => "Email dan password wajib diisi.",
    "email"   => "Format email tidak valid.",
    "invalid" => "Email atau password salah.",
];
$errorMsg = $errors[$_GET["error"] ?? ""] ?? "";
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Masuk • API WhatsApp</title>
  <style>
    :root {
      --wa: #128c7e;
      --wa-dark: #075e54;
      --wa-soft: #d9fdd3;
      --ink: #12221f;
      --muted: #5b6f6a;
      --line: #d7e4e0;
      --bg: #eef6f3;
      --card: #ffffff;
      --danger: #c0392b;
    }
    * { box-sizing: border-box; }
    html, body { margin: 0; padding: 0; }
    body {
      min-height: 100vh;
      font-family: "Segoe UI", system-ui, sans-serif;
      color: var(--ink);
      background:
        radial-gradient(1200px 500px at -10% -20%, #c8f0d8 0%, transparent 50%),
        radial-gradient(900px 400px at 110% 0%, #bfe8e0 0%, transparent 46%),
        var(--bg);
    }
    .wrap {
      max-width: 460px;
      margin: 0 auto;
      padding: 56px 16px 48px;
    }
    .badge {
      display: inline-block;
      background: var(--wa-soft);
      color: var(--wa-dark);
      font-size: 12px;
      font-weight: 700;
      letter-spacing: .04em;
      padding: 6px 10px;
      border-radius: 999px;
    }
    .card {
      background: var(--card);
      border: 1px solid #e3eeea;
      border-radius: 20px;
      padding: 22px 20px 18px;
      box-shadow: 0 18px 40px rgba(16, 64, 52, .08);
      margin-top: 14px;
    }
    .card h2 { margin: 0 0 4px; font-size: 22px; }
    .sub { margin: 0 0 18px; color: var(--muted); font-size: 14px; }
    form { display: grid; gap: 12px; }
    label { font-size: 13px; font-weight: 700; }
    .field { display: grid; gap: 6px; }
    .control { position: relative; }
    input {
      width: 100%;
      border: 1.5px solid var(--line);
      border-radius: 12px;
      padding: 12px 12px;
      font: inherit;
      color: var(--ink);
      background: #fbfefe;
      outline: none;
    }
    input:focus {
      border-color: var(--wa);
      box-shadow: 0 0 0 4px rgba(18, 140, 126, .15);
    }
    .eye {
      position: absolute;
      right: 8px; top: 50%;
      transform: translateY(-50%);
      border: 0; background: transparent;
      color: var(--muted);
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;
      padding: 6px;
    }
    .alert {
      background: #fdecea;
      border: 1px solid #f5c6c0;
      color: var(--danger);
      font-size: 13px;
      padding: 10px 12px;
      border-radius: 10px;
      margin-bottom: 14px;
    }
    button[type="submit"] {
      margin-top: 6px;
      width: 100%;
      border: 0;
      border-radius: 12px;
      padding: 13px 16px;
      background: linear-gradient(180deg, #1aaa7b, var(--wa-dark));
      color: white;
      font: inherit;
      font-weight: 800;
      cursor: pointer;
    }
    button[type="submit"]:hover { filter: brightness(1.05); }
    .foot { margin-top: 12px; font-size: 13px; text-align: center; color: var(--muted); }
    .foot a { color: var(--wa-dark); font-weight: 700; text-decoration: none; }
    .topnav { display:flex; justify-content:flex-end; gap:12px; padding:14px 16px 0; }
    .topnav a { color:#075e54; font-weight:800; text-decoration:none; }
  </style>
</head>
<body>
  <div class="topnav">
    <a href="index.php">Registrasi</a>
    <a href="laporan.php">Laporan</a>
  </div>
  <div class="wrap">
    <span class="badge">API WHATSAPP</span>
    <div class="card">
      <h2>Masuk ke akun</h2>
      <p class="sub">Login pakai email dan password yang sudah didaftarkan.</p>

      <?php if ($errorMsg): ?>
        <div class="alert"><?= htmlspecialchars($errorMsg) ?></div>
      <?php endif; ?>

      <form action="api/login.php" method="POST">
        <div class="field">
          <label for="email">Email</label>
          <input id="email" name="email" type="email" autocomplete="email" placeholder="nama@email.com" required />
        </div>

        <div class="field">
          <label for="password">Password</label>
          <div class="control">
            <input id="password" name="password" type="password" autocomplete="current-password" placeholder="Password" required />
            <button class="eye" type="button" id="togglePass">Lihat</button>
          </div>
        </div>

        <button type="submit">Masuk</button>
      </form>

      <p class="foot">Belum punya akun? <a href="index.php">Daftar di sini</a></p>
    </div>
  </div>

  <script>
    const toggle = document.getElementById("togglePass");
    const pass = document.getElementById("password");
    toggle.addEventListener("click", () => {
      const show = pass.type === "password";
      pass.type = show ? "text" : "password";
      toggle.textContent = show ? "Sembunyi" : "Lihat";
    });
  </script>
</body>
</html>
