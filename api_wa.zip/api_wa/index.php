<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Daftar Akun • API WhatsApp</title>
  <style>
    :root {
      --wa: #128c7e;
      --wa-dark: #075e54;
      --wa-soft: #d9fdd3;
      --ink: #12221f;
      --muted: #5b6f6a;
      --line: #d7e4e0;
      --bg: #eef6f3;
      --card: #ffffff;
      --danger: #c0392b;
      --ok: #0f8a4b;
    }
    * { box-sizing: border-box; }
    html, body { margin: 0; padding: 0; }
    body {
      min-height: 100vh;
      font-family: "Segoe UI", system-ui, sans-serif;
      color: var(--ink);
      background:
        radial-gradient(1200px 500px at -10% -20%, #c8f0d8 0%, transparent 50%),
        radial-gradient(900px 400px at 110% 0%, #bfe8e0 0%, transparent 46%),
        var(--bg);
    }
    .wrap {
      max-width: 880px;
      margin: 0 auto;
      padding: 28px 16px 48px;
      display: grid;
      grid-template-columns: 1fr;
      gap: 20px;
    }
    @media (min-width: 840px) {
      .wrap { grid-template-columns: 0.92fr 1.08fr; align-items: stretch; padding-top: 56px; }
    }
    .intro {
      padding: 12px 8px;
    }
    .badge {
      display: inline-block;
      background: var(--wa-soft);
      color: var(--wa-dark);
      font-size: 12px;
      font-weight: 700;
      letter-spacing: .04em;
      padding: 6px 10px;
      border-radius: 999px;
    }
    .intro h1 {
      margin: 12px 0 8px;
      font-size: 32px;
      line-height: 1.15;
    }
    .intro p { margin: 0; color: var(--muted); line-height: 1.55; }
    .card {
      background: var(--card);
      border: 1px solid #e3eeea;
      border-radius: 20px;
      padding: 22px 20px 18px;
      box-shadow: 0 18px 40px rgba(16, 64, 52, .08);
    }
    .card h2 { margin: 0 0 4px; font-size: 22px; }
    .sub { margin: 0 0 18px; color: var(--muted); font-size: 14px; }
    form { display: grid; gap: 12px; }
    label { font-size: 13px; font-weight: 700; }
    .field { display: grid; gap: 6px; }
    .control {
      position: relative;
    }
    input, textarea {
      width: 100%;
      border: 1.5px solid var(--line);
      border-radius: 12px;
      padding: 12px 12px;
      font: inherit;
      color: var(--ink);
      background: #fbfefe;
      outline: none;
    }
    textarea { min-height: 84px; resize: vertical; }
    input:focus, textarea:focus {
      border-color: var(--wa);
      box-shadow: 0 0 0 4px rgba(18, 140, 126, .15);
    }
    input.invalid, textarea.invalid { border-color: var(--danger); }
    .eye {
      position: absolute;
      right: 8px; top: 50%;
      transform: translateY(-50%);
      border: 0; background: transparent;
      color: var(--muted);
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;
      padding: 6px;
    }
    .hint { color: var(--muted); font-size: 12px; }
    .error { color: var(--danger); font-size: 12px; min-height: 16px; }
    .row { display: grid; gap: 12px; }
    @media (min-width: 640px) {
      .row { grid-template-columns: 1fr 1fr; }
    }
    button[type="submit"] {
      margin-top: 6px;
      width: 100%;
      border: 0;
      border-radius: 12px;
      padding: 13px 16px;
      background: linear-gradient(180deg, #1aaa7b, var(--wa-dark));
      color: white;
      font: inherit;
      font-weight: 800;
      cursor: pointer;
    }
    button[type="submit"]:hover { filter: brightness(1.05); }
    button[type="submit"]:disabled { opacity: .6; cursor: default; }
    .legal {
      margin-top: 10px;
      font-size: 12px;
      color: var(--muted);
      text-align: center;
    }
    .topnav { display:flex; justify-content:flex-end; gap:12px; padding:14px 16px 0; }
    .topnav a { color:#075e54; font-weight:800; text-decoration:none; }
  </style>
</head>
<body>
  <div class="topnav">
    <a href="index.php">Registrasi</a>
    <a href="login.php">Masuk</a>
    <a href="laporan.php">Laporan</a>
  </div>
  <div class="wrap">
    <section class="intro">
      <span class="badge">API WHATSAPP</span>
      <h1>Daftar dulu sebelum kirim pesan.</h1>
      <p>Isi data dengan bener. Nomor WA dipakai buat verifikasi, jadi tulis yang aktif. Password jangan dikasih ke siapa pun.</p>
    </section>

    <section class="card">
      <h2>Registrasi user</h2>
      <p class="sub">Semua kolom wajib diisi.</p>

      <form id="regForm" action="api/register.php" method="POST" novalidate>
        <div class="row">
          <div class="field">
            <label for="nama">Nama</label>
            <input id="nama" name="nama" type="text" autocomplete="name" placeholder="Nama lengkap" required />
            <div class="error" data-for="nama"></div>
          </div>
          <div class="field">
            <label for="email">Email</label>
            <input id="email" name="email" type="email" autocomplete="email" placeholder="nama@email.com" required />
            <div class="error" data-for="email"></div>
          </div>
        </div>

        <div class="field">
          <label for="no_hp">Nomor WhatsApp</label>
          <input id="no_hp" name="no_hp" type="tel" inputmode="numeric" autocomplete="tel" placeholder="081234567890" required />
          <div class="hint">Boleh 08..., 628..., atau +62...</div>
          <div class="error" data-for="no_hp"></div>
        </div>

        <div class="field">
          <label for="alamat">Alamat</label>
          <textarea id="alamat" name="alamat" placeholder="Jalan, kelurahan, kota" required></textarea>
          <div class="error" data-for="alamat"></div>
        </div>

        <div class="field">
          <label for="password">Password</label>
          <div class="control">
            <input id="password" name="password" type="password" autocomplete="new-password" minlength="8" placeholder="Minimal 8 karakter" required />
            <button class="eye" type="button" id="togglePass">Lihat</button>
          </div>
          <div class="error" data-for="password"></div>
        </div>

        <button type="submit" id="submitBtn">Daftar sekarang</button>
        <p class="legal">Dengan daftar, data dikirim ke <code>api/register.php</code>.</p>
      </form>
    </section>
  </div>

  <script>
    const form = document.getElementById("regForm");
    const toggle = document.getElementById("togglePass");
    const pass = document.getElementById("password");

    toggle.addEventListener("click", () => {
      const show = pass.type === "password";
      pass.type = show ? "text" : "password";
      toggle.textContent = show ? "Sembunyi" : "Lihat";
    });

    function setError(name, msg) {
      const el = document.querySelector('.error[data-for="' + name + '"]');
      const input = document.getElementById(name);
      if (el) el.textContent = msg || "";
      if (input) input.classList.toggle("invalid", Boolean(msg));
    }

    function validPhone(v) {
      const n = v.replace(/[^\d+]/g, "");
      return /^(?:\+62|62|0)8\d{8,11}$/.test(n);
    }

    form.addEventListener("submit", (e) => {
      let ok = true;
      const nama = form.nama.value.trim();
      const email = form.email.value.trim();
      const no = form.no_hp.value.trim();
      const alamat = form.alamat.value.trim();
      const password = form.password.value;

      setError("nama", nama.length < 2 ? "Nama minimal 2 huruf." : "");
      setError("email", !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? "Email belum valid." : "");
      setError("no_hp", validPhone(no) ? "" : "Nomor WA belum pas.");
      setError("alamat", alamat.length < 8 ? "Alamat terlalu pendek." : "");
      setError("password", password.length < 8 ? "Password minimal 8 karakter." : "");

      if (nama.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !validPhone(no) || alamat.length < 8 || password.length < 8) {
        e.preventDefault();
        ok = false;
      }
      if (ok) document.getElementById("submitBtn").disabled = true;
    });
  </script>
</body>
</html>