<?php

session_start();

require_once "../config/database.php";
require_once "../config/fonnte.php";
require_once "../functions/fonnte.php";

/*
|--------------------------------------------------------------------------
| CEK ADMIN
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION["user_id"]) || $_SESSION["user_role"] !== "admin") {
    header("Location: ../login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../admin.php");
    exit;
}

/*
|--------------------------------------------------------------------------
| ID USER
|--------------------------------------------------------------------------
*/

$id = intval($_POST["id"] ?? 0);

if ($id <= 0) {
    header("Location: ../admin.php?error=invalid");
    exit;
}

/*
|--------------------------------------------------------------------------
| JANGAN HAPUS AKUN SENDIRI
|--------------------------------------------------------------------------
*/

if ($id == $_SESSION["user_id"]) {
    header("Location: ../admin.php?error=self_delete");
    exit;
}

/*
|--------------------------------------------------------------------------
| AMBIL DATA USER SEBELUM DELETE
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT nama, email, no_hp
    FROM users
    WHERE id = ?
");

$stmt->bind_param(
    "i",
    $id
);

$stmt->execute();

$user = $stmt->get_result()->fetch_assoc();

$stmt->close();

/*
|--------------------------------------------------------------------------
| USER TIDAK DITEMUKAN
|--------------------------------------------------------------------------
*/

if (!$user) {

    $conn->close();

    header("Location: ../admin.php?error=invalid");
    exit;
}

/*
|--------------------------------------------------------------------------
| SIMPAN DATA UNTUK WA
|--------------------------------------------------------------------------
*/

$nama = $user["nama"];

$nomorTujuan = formatNomor(
    $user["no_hp"]
);

/*
|--------------------------------------------------------------------------
| DELETE DATABASE
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    DELETE FROM users
    WHERE id = ?
");

$stmt->bind_param(
    "i",
    $id
);

$berhasilDelete = $stmt->execute();

$stmt->close();

/*
|--------------------------------------------------------------------------
| DELETE GAGAL
|--------------------------------------------------------------------------
*/

if (!$berhasilDelete) {

    $conn->close();

    header("Location: ../admin.php?error=delete_failed");
    exit;
}

/*
|--------------------------------------------------------------------------
| KIRIM WA
|--------------------------------------------------------------------------
*/

$pesan = "🔔 AKUN TELAH DIHAPUS\n\n";

$pesan .= "Halo, " . $nama . ".\n\n";

$pesan .= "Akun Anda telah dihapus oleh admin.\n\n";

$pesan .= "Jika Anda merasa penghapusan ini tidak dilakukan oleh Anda, silakan hubungi admin.";

$wa = kirimWhatsApp(
    $nomorTujuan,
    $pesan
);

$conn->close();

/*
|--------------------------------------------------------------------------
| HASIL
|--------------------------------------------------------------------------
*/

if ($wa["success"]) {

    header("Location: ../admin.php?success=deleted_wa");
    exit;

}

header("Location: ../admin.php?success=deleted_wa_failed");
exit;