<?php
session_start();

require_once "../config/database.php";
require_once "../config/fonnte.php";
require_once "../functions/fonnte.php";

// Wajib login
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Method tidak diizinkan.");
}

$user_id  = (int) $_SESSION["user_id"];
$password = $_POST["password_konfirmasi"] ?? "";

if ($password === "") {
    header("Location: ../edit.php?hapus_error=empty");
    exit;
}

// Ambil data user + password hash buat verifikasi
$stmt = $conn->prepare("SELECT nama, email, no_hp, password FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    $conn->close();
    session_destroy();
    header("Location: ../login.php");
    exit;
}

if (!password_verify($password, $user["password"])) {
    $conn->close();
    header("Location: ../edit.php?hapus_error=invalid");
    exit;
}

// Hapus akun
$del = $conn->prepare("DELETE FROM users WHERE id = ?");
$del->bind_param("i", $user_id);
$sukses = $del->execute();
$del->close();
$conn->close();

if ($sukses) {

    // Kirim notif WA SEBELUM session dihapus (nomor & nama sudah diambil di atas)
    $pesan = "🗑️ AKUN DIHAPUS\n\n"
           . "Halo, {$user['nama']}.\n\n"
           . "Akun Anda dengan email {$user['email']} telah dihapus dari sistem "
           . "atas permintaan Anda sendiri.\n\n"
           . "Jika ini bukan Anda, segera hubungi admin.";

    kirimWhatsApp($user["no_hp"], $pesan);

    session_destroy();

    echo "<h2>Akun berhasil dihapus</h2>";
    echo "<p>Notifikasi konfirmasi sudah dikirim ke WhatsApp Anda.</p>";
    echo '<p><a href="../index.php">Kembali ke halaman daftar</a></p>';

} else {
    echo "<h2>Gagal menghapus akun</h2>";
    echo '<p><a href="../edit.php">Kembali</a></p>';
}
