<?php
require_once "../config/database.php";
require_once "../config/fonnte.php";
require_once "../functions/fonnte.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Method tidak diizinkan.");
}

$id = (int) ($_POST["id"] ?? 0);

if ($id <= 0) {
    die("ID tidak valid.");
}

// Ambil data dulu sebelum dihapus, buat isi pesan WA
$stmt = $conn->prepare("SELECT nama, email, no_hp FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    $conn->close();
    header("Location: ../laporan.php?hapus=notfound");
    exit;
}

$del = $conn->prepare("DELETE FROM users WHERE id = ?");
$del->bind_param("i", $id);
$sukses = $del->execute();
$del->close();
$conn->close();

if ($sukses) {
    $pesan = "🗑️ AKUN DIHAPUS\n\n"
           . "Halo, {$user['nama']}.\n\n"
           . "Akun Anda dengan email {$user['email']} telah dihapus dari sistem oleh admin.\n\n"
           . "Jika Anda merasa ini keliru, silakan hubungi admin untuk klarifikasi.";

    kirimWhatsApp($user["no_hp"], $pesan);

    header("Location: ../laporan.php?hapus=sukses");
} else {
    header("Location: ../laporan.php?hapus=gagal");
}
exit;
