<?php
session_start();

require_once "../config/database.php";
require_once "../config/fonnte.php";
require_once "../functions/fonnte.php";

// Wajib login
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Method tidak diizinkan.");
}

$user_id = (int) $_SESSION["user_id"];

// Ambil data dari form
$nama          = trim($_POST["nama"] ?? "");
$email         = trim($_POST["email"] ?? "");
$no_hp         = trim($_POST["no_hp"] ?? "");
$alamat        = trim($_POST["alamat"] ?? "");
$password_baru = $_POST["password_baru"] ?? "";

// Validasi dasar
if ($nama === "" || $email === "" || $no_hp === "" || $alamat === "") {
    die("Nama, email, nomor WA, dan alamat wajib diisi.");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Format email tidak valid.");
}

if ($password_baru !== "" && strlen($password_baru) < 8) {
    die("Password baru minimal 8 karakter.");
}

$no_hp_format = formatNomor($no_hp);

// Ambil data lama (buat perbandingan & isi pesan WA)
$old = $conn->prepare("SELECT nama, email, no_hp, alamat FROM users WHERE id = ?");
$old->bind_param("i", $user_id);
$old->execute();
$dataLama = $old->get_result()->fetch_assoc();
$old->close();

if (!$dataLama) {
    die("Data user tidak ditemukan.");
}

// Cek email / no_hp bentrok dengan user LAIN
$cek = $conn->prepare("SELECT id FROM users WHERE (email = ? OR no_hp = ?) AND id != ?");
$cek->bind_param("ssi", $email, $no_hp_format, $user_id);
$cek->execute();
$bentrok = $cek->get_result()->num_rows > 0;
$cek->close();

if ($bentrok) {
    die("Email atau nomor WhatsApp sudah dipakai user lain.");
}

// Update data (dengan atau tanpa ganti password)
if ($password_baru !== "") {
    $password_hash = password_hash($password_baru, PASSWORD_DEFAULT);
    $stmt = $conn->prepare(
        "UPDATE users SET nama = ?, email = ?, no_hp = ?, alamat = ?, password = ? WHERE id = ?"
    );
    $stmt->bind_param("sssssi", $nama, $email, $no_hp_format, $alamat, $password_hash, $user_id);
} else {
    $stmt = $conn->prepare(
        "UPDATE users SET nama = ?, email = ?, no_hp = ?, alamat = ? WHERE id = ?"
    );
    $stmt->bind_param("ssssi", $nama, $email, $no_hp_format, $alamat, $user_id);
}

if ($stmt->execute()) {

    // Update session biar konsisten
    $_SESSION["user_nama"]  = $nama;
    $_SESSION["user_email"] = $email;

    // Susun daftar field yang berubah
    $perubahan = [];
    if ($dataLama["nama"] !== $nama)          $perubahan[] = "• Nama: {$dataLama['nama']} → $nama";
    if ($dataLama["email"] !== $email)        $perubahan[] = "• Email: {$dataLama['email']} → $email";
    if ($dataLama["no_hp"] !== $no_hp_format) $perubahan[] = "• WhatsApp: {$dataLama['no_hp']} → $no_hp_format";
    if ($dataLama["alamat"] !== $alamat)      $perubahan[] = "• Alamat: {$dataLama['alamat']} → $alamat";
    if ($password_baru !== "")                $perubahan[] = "• Password: diperbarui";

    echo "<h2>Data berhasil diperbarui!</h2>";
    echo "<p>Nama: " . htmlspecialchars($nama) . "</p>";
    echo "<p>Email: " . htmlspecialchars($email) . "</p>";

    if (count($perubahan) > 0) {
        $pesan = "🔔 DATA AKUN DIPERBARUI\n\n"
               . "Halo, $nama!\n\n"
               . "Berikut perubahan pada akun Anda:\n"
               . implode("\n", $perubahan) . "\n\n"
               . "Jika Anda tidak melakukan perubahan ini, segera hubungi admin.";

        // Kirim notifikasi ke nomor WA TERBARU
        $wa = kirimWhatsApp($no_hp_format, $pesan);

        if ($wa["success"]) {
            echo "<p>✅ Notifikasi WhatsApp berhasil diproses.</p>";
        } else {
            echo "<p>⚠️ Data berhasil diperbarui, tetapi WhatsApp gagal dikirim.</p>";
            echo "<p>Error: " . htmlspecialchars($wa["message"]) . "</p>";
        }
    } else {
        echo "<p>ℹ️ Tidak ada perubahan data, notifikasi WA tidak dikirim.</p>";
    }

    echo '<p><a href="../edit.php">Kembali ke halaman edit</a></p>';

} else {
    echo "<h2>Update Gagal</h2>";
    echo "<p>" . htmlspecialchars($stmt->error) . "</p>";
}

$stmt->close();
$conn->close();
