<?php

session_start();

require_once "../config/database.php";
require_once "../config/fonnte.php";
require_once "../functions/fonnte.php";

/*
|--------------------------------------------------------------------------
| CEK ADMIN
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION["user_id"]) || $_SESSION["user_role"] !== "admin") {
    header("Location: ../login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../admin.php");
    exit;
}

/*
|--------------------------------------------------------------------------
| AMBIL DATA FORM
|--------------------------------------------------------------------------
*/

$id       = intval($_POST["id"] ?? 0);
$nama     = trim($_POST["nama"] ?? "");
$email    = trim($_POST["email"] ?? "");
$no_hp    = trim($_POST["no_hp"] ?? "");
$alamat   = trim($_POST["alamat"] ?? "");
$password = $_POST["password"] ?? "";
$role     = $_POST["role"] ?? "user";

/*
|--------------------------------------------------------------------------
| VALIDASI
|--------------------------------------------------------------------------
*/

if (
    $id <= 0 ||
    $nama === "" ||
    $email === "" ||
    $no_hp === "" ||
    $alamat === ""
) {
    header("Location: ../admin.php?error=empty");
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header("Location: ../admin.php?error=email");
    exit;
}

if (!in_array($role, ["admin", "user"])) {
    $role = "user";
}

/*
|--------------------------------------------------------------------------
| AMBIL DATA LAMA
|--------------------------------------------------------------------------
| Ini penting supaya kita tahu data apa yang berubah.
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT id, nama, email, no_hp, alamat, role
    FROM users
    WHERE id = ?
");

$stmt->bind_param("i", $id);
$stmt->execute();

$oldUser = $stmt->get_result()->fetch_assoc();

$stmt->close();

if (!$oldUser) {
    header("Location: ../admin.php?error=invalid");
    exit;
}

/*
|--------------------------------------------------------------------------
| CEK EMAIL
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT id
    FROM users
    WHERE email = ?
    AND id != ?
");

$stmt->bind_param("si", $email, $id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows > 0) {

    $stmt->close();
    $conn->close();

    header("Location: ../admin.php?error=email_exists");
    exit;
}

$stmt->close();

/*
|--------------------------------------------------------------------------
| CEK PERUBAHAN DATA
|--------------------------------------------------------------------------
*/

$perubahan = [];

if ($oldUser["nama"] !== $nama) {
    $perubahan[] =
        "Nama: " .
        $oldUser["nama"] .
        " → " .
        $nama;
}

if ($oldUser["email"] !== $email) {
    $perubahan[] =
        "Email: " .
        $oldUser["email"] .
        " → " .
        $email;
}

if ($oldUser["no_hp"] !== $no_hp) {
    $perubahan[] =
        "Nomor WhatsApp: " .
        $oldUser["no_hp"] .
        " → " .
        $no_hp;
}

if ($oldUser["alamat"] !== $alamat) {
    $perubahan[] =
        "Alamat: " .
        $oldUser["alamat"] .
        " → " .
        $alamat;
}

if ($oldUser["role"] !== $role) {
    $perubahan[] =
        "Role: " .
        $oldUser["role"] .
        " → " .
        $role;
}

if ($password !== "") {
    $perubahan[] = "Password: berhasil diubah";
}

/*
|--------------------------------------------------------------------------
| UPDATE DATABASE
|--------------------------------------------------------------------------
*/

if ($password === "") {

    $stmt = $conn->prepare("
        UPDATE users
        SET
            nama = ?,
            email = ?,
            no_hp = ?,
            alamat = ?,
            role = ?
        WHERE id = ?
    ");

    $stmt->bind_param(
        "sssssi",
        $nama,
        $email,
        $no_hp,
        $alamat,
        $role,
        $id
    );

} else {

    $passwordHash = password_hash(
        $password,
        PASSWORD_DEFAULT
    );

    $stmt = $conn->prepare("
        UPDATE users
        SET
            nama = ?,
            email = ?,
            no_hp = ?,
            alamat = ?,
            password = ?,
            role = ?
        WHERE id = ?
    ");

    $stmt->bind_param(
        "ssssssi",
        $nama,
        $email,
        $no_hp,
        $alamat,
        $passwordHash,
        $role,
        $id
    );
}

$berhasilUpdate = $stmt->execute();

$stmt->close();

/*
|--------------------------------------------------------------------------
| JIKA UPDATE GAGAL
|--------------------------------------------------------------------------
*/

if (!$berhasilUpdate) {

    $conn->close();

    header("Location: ../admin.php?error=update_failed");
    exit;
}

/*
|--------------------------------------------------------------------------
| KIRIM WHATSAPP
|--------------------------------------------------------------------------
*/

$waBerhasil = false;
$waMessage = "";

/*
|--------------------------------------------------------------------------
| HANYA KIRIM WA JIKA ADA PERUBAHAN
|--------------------------------------------------------------------------
*/

if (count($perubahan) > 0) {

    /*
    | Nomor tujuan menggunakan nomor terbaru.
    */

    $nomorTujuan = formatNomor($no_hp);

    $pesan = "🔔 DATA AKUN DIPERBARUI\n\n";

    $pesan .= "Halo, " . $nama . "!\n\n";

    $pesan .= "Data akun Anda berhasil diperbarui oleh admin.\n\n";

    $pesan .= "📋 PERUBAHAN DATA:\n";

    foreach ($perubahan as $item) {
        $pesan .= "• " . $item . "\n";
    }

    $pesan .= "\n";

    $pesan .= "Jika perubahan ini bukan dilakukan oleh Anda, silakan hubungi admin.\n\n";

    $pesan .= "Terima kasih.";

    $wa = kirimWhatsApp(
        $nomorTujuan,
        $pesan
    );

    $waBerhasil = $wa["success"];

    if (!$waBerhasil) {
        $waMessage = $wa["message"] ?? "WhatsApp gagal dikirim.";
    }
}

/*
|--------------------------------------------------------------------------
| TUTUP DATABASE
|--------------------------------------------------------------------------
*/

$conn->close();

/*
|--------------------------------------------------------------------------
| REDIRECT
|--------------------------------------------------------------------------
*/

if ($waBerhasil) {

    header("Location: ../admin.php?success=updated_wa");
    exit;

}

if (count($perubahan) > 0) {

    header("Location: ../admin.php?success=updated_wa_failed");
    exit;

}

header("Location: ../admin.php?success=updated");
exit;