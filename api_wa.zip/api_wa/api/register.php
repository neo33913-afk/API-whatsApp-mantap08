<?php

require_once "../config/database.php";
require_once "../config/fonnte.php";
require_once "../functions/fonnte.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Method tidak diizinkan.");
}

// Ambil data dari form
$nama     = trim($_POST["nama"] ?? "");
$email    = trim($_POST["email"] ?? "");
$no_hp    = trim($_POST["no_hp"] ?? "");
$alamat   = trim($_POST["alamat"] ?? "");
$password = $_POST["password"] ?? "";

// Validasi
if ($nama === "" || $email === "" || $no_hp === "" || $alamat === "" || $password === "") {
    die("Semua data wajib diisi.");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Format email tidak valid.");
}

// Normalisasi nomor
$no_hp_format = formatNomor($no_hp);

// Cek email atau nomor sudah ada
$cek = $conn->prepare(
    "SELECT id FROM users WHERE email = ? OR no_hp = ?"
);

$cek->bind_param("ss", $email, $no_hp_format);
$cek->execute();

$result = $cek->get_result();

if ($result->num_rows > 0) {
    die("Email atau nomor WhatsApp sudah terdaftar.");
}

// Hash password
$password_hash = password_hash($password, PASSWORD_DEFAULT);

// Simpan user
$stmt = $conn->prepare(
    "INSERT INTO users (nama, email, no_hp, alamat, password)
     VALUES (?, ?, ?, ?, ?)"
);

$stmt->bind_param(
    "sssss",
    $nama,
    $email,
    $no_hp_format,
    $alamat,
    $password_hash
);

if ($stmt->execute()) {

    // Buat pesan WhatsApp
    $pesan = "🎉 REGISTRASI BERHASIL\n\n"
           . "Selamat, $nama!\n\n"
           . "Akun Anda telah berhasil dibuat.\n\n"
           . "📧 Email: $email\n"
           . "📱 WhatsApp: $no_hp\n"
           . "📍 Alamat: $alamat\n\n"
           . "Terima kasih telah melakukan registrasi.";

    // Kirim WhatsApp SETELAH database berhasil
    $wa = kirimWhatsApp($no_hp_format, $pesan);

    echo "<h2>Registrasi Berhasil!</h2>";
    echo "<p>Nama: $nama</p>";
    echo "<p>Email: $email</p>";

    if ($wa["success"]) {
        echo "<p>✅ Notifikasi WhatsApp berhasil diproses.</p>";
    } else {
        echo "<p>⚠️ Registrasi berhasil, tetapi WhatsApp gagal dikirim.</p>";
        echo "<p>Error: " . htmlspecialchars($wa["message"]) . "</p>";
    }

} else {

    echo "<h2>Registrasi Gagal</h2>";
    echo "<p>" . htmlspecialchars($stmt->error) . "</p>";
}

$stmt->close();
$cek->close();
$conn->close();