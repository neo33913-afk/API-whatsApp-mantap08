<?php

session_start();

require_once "../config/database.php";
require_once "../config/fonnte.php";
require_once "../functions/fonnte.php";

/*
|--------------------------------------------------------------------------
| CEK ADMIN
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION["user_id"]) || $_SESSION["user_role"] !== "admin") {
    header("Location: ../login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../admin.php");
    exit;
}

/*
|--------------------------------------------------------------------------
| AMBIL DATA
|--------------------------------------------------------------------------
*/

$nama     = trim($_POST["nama"] ?? "");
$email    = trim($_POST["email"] ?? "");
$no_hp    = trim($_POST["no_hp"] ?? "");
$alamat   = trim($_POST["alamat"] ?? "");
$password = $_POST["password"] ?? "";
$role     = $_POST["role"] ?? "user";

/*
|--------------------------------------------------------------------------
| VALIDASI
|--------------------------------------------------------------------------
*/

if (
    $nama === "" ||
    $email === "" ||
    $no_hp === "" ||
    $alamat === "" ||
    $password === ""
) {
    header("Location: ../admin.php?error=empty");
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header("Location: ../admin.php?error=email");
    exit;
}

if (!in_array($role, ["admin", "user"])) {
    $role = "user";
}

/*
|--------------------------------------------------------------------------
| FORMAT NOMOR
|--------------------------------------------------------------------------
*/

$no_hp_format = formatNomor($no_hp);

/*
|--------------------------------------------------------------------------
| CEK EMAIL / NOMOR
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT id
    FROM users
    WHERE email = ?
    OR no_hp = ?
");

$stmt->bind_param(
    "ss",
    $email,
    $no_hp_format
);

$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows > 0) {

    $stmt->close();
    $conn->close();

    header("Location: ../admin.php?error=email_exists");
    exit;
}

$stmt->close();

/*
|--------------------------------------------------------------------------
| HASH PASSWORD
|--------------------------------------------------------------------------
*/

$passwordHash = password_hash(
    $password,
    PASSWORD_DEFAULT
);

/*
|--------------------------------------------------------------------------
| INSERT USER
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    INSERT INTO users
    (
        nama,
        email,
        no_hp,
        alamat,
        password,
        role
    )
    VALUES (?, ?, ?, ?, ?, ?)
");

$stmt->bind_param(
    "ssssss",
    $nama,
    $email,
    $no_hp_format,
    $alamat,
    $passwordHash,
    $role
);

$berhasil = $stmt->execute();

/*
|--------------------------------------------------------------------------
| INSERT GAGAL
|--------------------------------------------------------------------------
*/

if (!$berhasil) {

    $stmt->close();
    $conn->close();

    header("Location: ../admin.php?error=create_failed");
    exit;
}

$stmt->close();

/*
|--------------------------------------------------------------------------
| KIRIM WHATSAPP
|--------------------------------------------------------------------------
*/

$pesan = "🎉 AKUN BERHASIL DIBUAT\n\n";

$pesan .= "Halo, " . $nama . "!\n\n";

$pesan .= "Akun Anda telah dibuat oleh admin.\n\n";

$pesan .= "📧 Email: " . $email . "\n";
$pesan .= "📱 WhatsApp: " . $no_hp_format . "\n";
$pesan .= "👤 Role: " . $role . "\n";
$pesan .= "📍 Alamat: " . $alamat . "\n\n";

$pesan .= "🔐 Password: " . $password . "\n\n";

$pesan .= "Silakan login menggunakan akun tersebut.\n\n";

$pesan .= "Terima kasih.";

$wa = kirimWhatsApp(
    $no_hp_format,
    $pesan
);

$conn->close();

/*
|--------------------------------------------------------------------------
| HASIL
|--------------------------------------------------------------------------
*/

if ($wa["success"]) {

    header("Location: ../admin.php?success=created_wa");
    exit;

}

header("Location: ../admin.php?success=created_wa_failed");
exit;