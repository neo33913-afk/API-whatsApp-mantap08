<?php

session_start();

require_once "../config/database.php";
require_once "../config/fonnte.php";
require_once "../functions/fonnte.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../login.php");
    exit;
}

$email    = trim($_POST["email"] ?? "");
$password = $_POST["password"] ?? "";

if ($email === "" || $password === "") {
    header("Location: ../login.php?error=empty");
    exit;
}

/*
|--------------------------------------------------------------------------
| Cari user berdasarkan email
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT
        id,
        nama,
        email,
        no_hp,
        password,
        role
    FROM users
    WHERE email = ?
");

$stmt->bind_param("s", $email);
$stmt->execute();

$result = $stmt->get_result();

$user = $result->fetch_assoc();

$stmt->close();

if (!$user) {
    $conn->close();

    header("Location: ../login.php?error=login");
    exit;
}

/*
|--------------------------------------------------------------------------
| Cek password
|--------------------------------------------------------------------------
*/

if (!password_verify($password, $user["password"])) {
    $conn->close();

    header("Location: ../login.php?error=login");
    exit;
}

/*
|--------------------------------------------------------------------------
| Simpan session
|--------------------------------------------------------------------------
*/

$_SESSION["user_id"]    = $user["id"];
$_SESSION["user_nama"]  = $user["nama"];
$_SESSION["user_email"] = $user["email"];
$_SESSION["user_role"]  = $user["role"];

/*
|--------------------------------------------------------------------------
| Kirim notifikasi WhatsApp
|--------------------------------------------------------------------------
*/

$nomorTujuan = formatNomor($user["no_hp"]);

$pesan = "🔐 LOGIN BERHASIL\n\n";

$pesan .= "Halo, " . $user["nama"] . "!\n\n";

$pesan .= "Anda berhasil login ke sistem.\n\n";

$pesan .= "📧 Email: " . $user["email"] . "\n";
$pesan .= "📱 Nomor: " . $user["no_hp"] . "\n";

$pesan .= "\n";

$pesan .= "Jika Anda tidak merasa melakukan login, segera hubungi admin.\n\n";

$pesan .= "Terima kasih.";

$wa = kirimWhatsApp(
    $nomorTujuan,
    $pesan
);

/*
|--------------------------------------------------------------------------
| Redirect sesuai role
|--------------------------------------------------------------------------
*/

$conn->close();

if ($user["role"] === "admin") {
    header("Location: ../admin.php");
    exit;
}

header("Location: ../edit.php");
exit;