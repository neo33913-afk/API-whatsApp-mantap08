<?php
$dbFile = __DIR__ . "/config/database.php";
if (!is_file($dbFile)) {
    $dbFile = __DIR__ . "/../config/database.php";
}
require_once $dbFile;

function h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, "UTF-8");
}

$q = trim($_GET["q"] ?? "");
$dari = trim($_GET["dari"] ?? "");
$sampai = trim($_GET["sampai"] ?? "");

$where = [];
$types = "";
$params = [];

if ($q !== "") {
    $where[] = "(nama LIKE ? OR email LIKE ? OR no_hp LIKE ? OR alamat LIKE ?)";
    $like = "%" . $q . "%";
    $types .= "ssss";
    array_push($params, $like, $like, $like, $like);
}
if ($dari !== "") {
    $where[] = "DATE(created_at) >= ?";
    $types .= "s";
    $params[] = $dari;
}
if ($sampai !== "") {
    $where[] = "DATE(created_at) <= ?";
    $types .= "s";
    $params[] = $sampai;
}

$sql = "SELECT id, nama, email, no_hp, alamat, created_at FROM users";
if ($where) {
    $sql .= " WHERE " . implode(" AND ", $where);
}
$sql .= " ORDER BY created_at DESC, id DESC";

$stmt = $conn->prepare($sql);
if ($types !== "") {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$totalAll = (int)$conn->query("SELECT COUNT(*) AS n FROM users")->fetch_assoc()["n"];
$today = (int)$conn->query("SELECT COUNT(*) AS n FROM users WHERE DATE(created_at) = CURDATE()")->fetch_assoc()["n"];
$week = (int)$conn->query("SELECT COUNT(*) AS n FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetch_assoc()["n"];

$hapusStatus = $_GET["hapus"] ?? "";
$hapusPesan = [
    "sukses"   => ["ok", "User berhasil dihapus, notifikasi WA sudah dikirim."],
    "gagal"    => ["err", "Gagal menghapus user."],
    "notfound" => ["err", "User tidak ditemukan."],
][$hapusStatus] ?? null;
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Riwayat Registrasi</title>
  <style>
    :root {
      --wa: #128c7e;
      --wa-dark: #075e54;
      --wa-soft: #d9fdd3;
      --ink: #12221f;
      --muted: #5b6f6a;
      --line: #d7e4e0;
      --bg: #eef6f3;
      --card: #fff;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: "Segoe UI", system-ui, sans-serif;
      background: var(--bg);
      color: var(--ink);
    }
    .bar {
      display: flex; justify-content: space-between; align-items: center;
      gap: 10px; flex-wrap: wrap;
      padding: 14px 16px; background: #fff;
      border-bottom: 1px solid var(--line);
    }
    .brand { font-weight: 800; color: var(--wa-dark); }
    .bar a { color: var(--wa-dark); font-weight: 700; text-decoration: none; }
    .page { max-width: 1100px; margin: 0 auto; padding: 18px 16px 40px; }
    .stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 14px; }
    @media (max-width: 700px) { .stats { grid-template-columns: 1fr; } }
    .stat { background: var(--wa-soft); border-radius: 14px; padding: 14px; }
    .stat span { display: block; font-size: 12px; font-weight: 700; color: var(--wa-dark); }
    .stat strong { font-size: 26px; }
    .card {
      background: var(--card);
      border: 1px solid #e3eeea;
      border-radius: 16px;
      padding: 16px;
    }
    form.filters {
      display: grid;
      grid-template-columns: 1.4fr 1fr 1fr auto;
      gap: 8px;
      margin-bottom: 14px;
    }
    @media (max-width: 800px) { form.filters { grid-template-columns: 1fr; } }
    input {
      width: 100%;
      border: 1.5px solid var(--line);
      border-radius: 10px;
      padding: 10px 12px;
      font: inherit;
    }
    button, .ghost {
      border: 0; border-radius: 10px; padding: 10px 14px;
      font: inherit; font-weight: 800; cursor: pointer;
      background: var(--wa-dark); color: #fff; text-decoration: none; display: inline-block;
    }
    .ghost { background: #dceee9; color: var(--wa-dark); }
    table { width: 100%; border-collapse: collapse; font-size: 13px; }
    th, td { text-align: left; padding: 10px 8px; border-bottom: 1px solid var(--line); vertical-align: top; }
    th { color: var(--wa-dark); font-size: 12px; }
    .empty { text-align: center; color: var(--muted); padding: 28px 8px; }
    .muted { color: var(--muted); font-size: 12px; }
    .alert-box {
      font-size: 13px;
      padding: 10px 12px;
      border-radius: 10px;
      margin-bottom: 14px;
    }
    .alert-box.ok { background: var(--wa-soft); color: var(--wa-dark); }
    .alert-box.err { background: #fdecea; color: #c0392b; }
    .btn-del {
      border: 0; border-radius: 8px; padding: 6px 10px;
      font-size: 12px; font-weight: 800; cursor: pointer;
      background: #fdecea; color: #c0392b;
    }
    .btn-del:hover { background: #f7d3ce; }
  </style>
</head>
<body>
  <div class="bar">
    <div class="brand">Riwayat Registrasi</div>
    <div>
      <a href="index.php">Form daftar</a>
      <a href="login.php">Masuk</a>
    </div>
  </div>

  <div class="page">
    <div class="stats">
      <div class="stat"><span>Total terdaftar</span><strong><?= $totalAll ?></strong></div>
      <div class="stat"><span>Hari ini</span><strong><?= $today ?></strong></div>
      <div class="stat"><span>7 hari terakhir</span><strong><?= $week ?></strong></div>
    </div>

    <div class="card">
      <form class="filters" method="GET">
        <input type="text" name="q" value="<?= h($q) ?>" placeholder="Cari nama, email, nomor, alamat" />
        <input type="date" name="dari" value="<?= h($dari) ?>" />
        <input type="date" name="sampai" value="<?= h($sampai) ?>" />
        <div>
          <button type="submit">Filter</button>
          <a class="ghost" href="laporan.php">Reset</a>
        </div>
      </form>

      <?php if ($hapusPesan): ?>
        <div class="alert-box <?= h($hapusPesan[0]) ?>"><?= h($hapusPesan[1]) ?></div>
      <?php endif; ?>

      <p class="muted">Menampilkan <?= count($rows) ?> data. Password tidak ditampilkan.</p>

      <?php if (!$rows): ?>
        <div class="empty">Belum ada riwayat registrasi.</div>
      <?php else: ?>
      <div style="overflow:auto">
        <table>
          <thead>
            <tr>
              <th>Waktu</th>
              <th>Nama</th>
              <th>Email</th>
              <th>WhatsApp</th>
              <th>Alamat</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($rows as $u): ?>
              <tr>
                <td><?= h($u["created_at"]) ?></td>
                <td><?= h($u["nama"]) ?></td>
                <td><?= h($u["email"]) ?></td>
                <td><?= h($u["no_hp"]) ?></td>
                <td><?= h($u["alamat"]) ?></td>
                <td>
                  <form action="api/delete_admin.php" method="POST"
                        onsubmit="return confirm('Hapus akun <?= h($u["nama"]) ?>? Notifikasi WA akan dikirim ke user ini.');">
                    <input type="hidden" name="id" value="<?= h($u["id"]) ?>" />
                    <button type="submit" class="btn-del">Hapus</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>
<?php $conn->close(); ?>