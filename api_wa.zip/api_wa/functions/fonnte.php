<?php

function formatNomor($nomor)
{
    $nomor = preg_replace('/[^0-9]/', '', $nomor);

    if (substr($nomor, 0, 1) == '0') {
        $nomor = '62' . substr($nomor, 1);
    }

    return $nomor;
}

function kirimWhatsApp($nomor, $pesan)
{
    global $fonnte_token;

    $curl = curl_init();

    curl_setopt_array($curl, [
        CURLOPT_URL => 'https://api.fonnte.com/send',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => 'POST',

        CURLOPT_POSTFIELDS => [
            'target' => $nomor,
            'message' => $pesan,
            'countryCode' => '62'
        ],

        CURLOPT_HTTPHEADER => [
            'Authorization: ' . $fonnte_token
        ],
    ]);

    $response = curl_exec($curl);

    if (curl_errno($curl)) {
        $error = curl_error($curl);
        curl_close($curl);

        return [
            'success' => false,
            'message' => $error
        ];
    }

    curl_close($curl);

    return [
        'success' => true,
        'response' => $response
    ];
}